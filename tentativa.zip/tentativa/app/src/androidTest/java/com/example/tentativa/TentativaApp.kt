package com.example.tentativa

import android.app.Application
import androidx.room.Room
import com.example.tentativa.database.AppDatabase
import com.example.tentativa.entity.Pergunta
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TentativaApp : Application() {

    companion object {
        lateinit var database: AppDatabase
    }

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "quiz-database"
        ).build()

        // Inserir dados na tabela Pergunta
        CoroutineScope(Dispatchers.IO).launch {
            val perguntaDao = database.perguntaDao()
            val perguntas = arrayOf(
                Pergunta(tema = 1, pergunta = "Quem foi o autor de Dom Quixote, frequentemente considerado o primeiro romance moderno?", respostaCerta = "Miguel de Cervantes", opcao1 = "William Shakespeare", opcao2 = "Jane Austen"),
                Pergunta(tema = 1, pergunta = "Qual é o nome da técnica artística que envolve cortar e colar pedaços de papel para criar uma imagem?", respostaCerta = "Colagem", opcao1 = "Aquarela", opcao2 = "Gravura"),
                Pergunta(tema = 1, pergunta = "Quem foi o fundador do surrealismo, conhecido por suas obras de arte oníricas e estranhas?", respostaCerta = "André Breton", opcao1 = "Vincent van Gogh", opcao2 = "Pablo Picasso"),
                Pergunta(tema = 1, pergunta = "Todos os anos os melhores filmes e cineastas são galardoados com os Óscares da Academia em Los Angeles. Alguns filmes conseguem bater muitos recordes. Qual foi o primeiro filme da história do cinema a receber dez destas famosas estatuetas?", respostaCerta = "E tudo que o vento levou", opcao1 = "Titanic", opcao2 = "Ben Hur"),
                Pergunta(tema = 1, pergunta = "Em 1996, o mundo desabou para muitas raparigas quando a sua boysband favorita anunciou de forma inesperada a dissolução do grupo. Que banda partiu tantos corações?", respostaCerta = "Take that", opcao1 = "New Kids on the Block", opcao2 = "*NSYNC"),
                Pergunta(tema = 1, pergunta = "Quem é conhecido como o Rei do Pop e teve sucessos como Thriller e Billie Jean?", respostaCerta = "Michael Jackson", opcao1 = "Elvis Presley", opcao2 = "Prince"),
                Pergunta(tema = 1, pergunta = "Qual instrumento tem teclas brancas e pretas e é comumente associado à música clássica?", respostaCerta = "Piano", opcao1 = "Violino", opcao2 = "Acordeão"),
                Pergunta(tema = 1, pergunta = "Qual banda britânica é famosa por álbuns como The Dark Side of the Moon e The Wall?", respostaCerta = "Pink Floyd", opcao1 = "The Rolling Stones", opcao2 = "The Who"),
                Pergunta(tema = 1, pergunta = "Quem é a vocalista da banda de rock Fleetwood Mac, conhecida por hits como Go Your Own Way?", respostaCerta = "Stevie Nicks", opcao1 = "Christine McVie", opcao2 = "Mick Fleetwood"),
                Pergunta(tema = 1, pergunta = "Qual gênero musical originou-se nos Estados Unidos na década de 1970 e é caracterizado por batidas rítmicas e rimas faladas?", respostaCerta = "Hip-hop", opcao1 = "Country", opcao2 = "Jazz"),
                Pergunta(tema = 1, pergunta = "Quem foi o icônico guitarrista da banda Queen, conhecido por seu estilo único e virtuosismo?", respostaCerta = "Brian May", opcao1 = "Jimmy Page", opcao2 = "Eric Clapton"),
                Pergunta(tema = 1, pergunta = "Qual é o álbum mais vendido de todos os tempos?", respostaCerta = "Thriller de Michael Jackson", opcao1 = "Abbey Road", opcao2 = "Back in Black"),
                Pergunta(tema = 1, pergunta = "Qual é o nome da premiação anual da indústria musical dos Estados Unidos?", respostaCerta = "Grammy Awards", opcao1 = "MTV Music Awards", opcao2 = "American Music Awards"),
                Pergunta(tema = 1, pergunta = "Qual é o nome do festival de música que acontece anualmente em Indio, Califórnia, e é famoso por suas apresentações ao vivo?", respostaCerta = "Coachella", opcao1 = "Lollapalooza", opcao2 = "Bonnaroo"),
                Pergunta(tema = 2, pergunta = "As cataratas do Niágara incluem-se entre as quedas de água mais famosas do mundo. Situadas no Estado de Nova lorque, estas cataratas ficam entre dois lagos enormes. Como se chamam os lagos? É o…", respostaCerta = "Lago Erie e o lago Ontário", opcao1 = "Lago Erie e lago Superior", opcao2 = "Lago Erie e o lago Michigan"),
                Pergunta(tema = 2, pergunta = "Qual é o maior rio do mundo em volume de água?", respostaCerta = "Rio Amazonas", opcao1 = "Rio Nilo", opcao2 = "Rio Yangtzé"),
                Pergunta(tema = 2, pergunta = "Quais são os cinco maiores países do mundo em termos de área territorial?", respostaCerta = "Rússia, Canadá, Estados Unidos, China e Brasil", opcao1 = "Rússia, Brasil, Índia, China, Estados Unidos", opcao2 = "Canadá, Austrália, Estados Unidos, China, Índia"),
                Pergunta(tema = 2, pergunta = "Em que continente está localizado o Deserto do Saara", respostaCerta = "África", opcao1 = "América do Sul", opcao2 = "Ásia"),
                Pergunta(tema = 2, pergunta = "Qual é o ponto mais baixo da Terra, localizado na Fossa das Marianas?", respostaCerta = "Challenger Deep", opcao1 = "Abismo do Desespero", opcao2 = "Vale das Sombras"),
                Pergunta(tema = 2, pergunta = "Quais são os três maiores rios do mundo em termos de volume de água?", respostaCerta = "Amazonas, Nilo e Yangtzé", opcao1 = "Rio Nilo, Rio Amazonas, Rio Tâmisa", opcao2 = "Rio Mississippi, Rio Ganges, Rio Amur"),
                Pergunta(tema = 2, pergunta = "Qual é a capital do Canadá?", respostaCerta = "Ottawa", opcao1 = "Vancouver", opcao2 = "Toronto"),
                Pergunta(tema = 2, pergunta = "Em que continente está localizado o Monte Kilimanjaro?", respostaCerta = "África", opcao1 = "Ásia", opcao2 = "América do Sul"),
                Pergunta(tema = 2, pergunta = "Quais são os cinco oceanos da Terra?", respostaCerta = "Pacífico, Atlântico, Índico, Antártico e Ártico", opcao1 = "Pacífico, Atlântico, Índico, Mar Mediterrâneo, Mar do Norte", opcao2 = "Mar de Coral, Mar de Bering, Oceano Antártico, Mar de Aral, Oceano Ártico"),
                Pergunta(tema = 2, pergunta = "Qual é o país mais populoso do mundo?", respostaCerta = "China", opcao1 = "Índia", opcao2 = "Estados Unidos"),
                Pergunta(tema = 2, pergunta = "Onde está localizado o Deserto do Atacama, considerado o deserto mais seco do mundo?", respostaCerta = "Chile", opcao1 = "Austrália", opcao2 = "Rússia"),
                Pergunta(tema = 2, pergunta = "Quais são os quatro pontos cardeais?(em ordem)", respostaCerta = "Norte, Sul, Este e Oeste", opcao1 = "Norte, Oeste, Sul, Este", opcao2 = "Leste, Norte, Oeste, Sul"),
                Pergunta(tema = 2, pergunta = "Qual é o maior arquipélago do mundo em termos de número de ilhas?", respostaCerta = "Indonésia", opcao1 = "Havaí", opcao2 = "Japão"),
                Pergunta(tema = 2, pergunta = "Quais são os dois países que compartilham a ilha de Hispaniola no Caribe?", respostaCerta = "Haiti e República Dominicana", opcao1 = "Cuba e Jamaica", opcao2 = "Porto Rico e Bahamas"),
                Pergunta(tema = 3, pergunta = "No período da Baixa Idade Média, os imperadores alemães eram nomeados por sete príncipes-eleitores. Qual destes bispos não fazia parte do grupo?", respostaCerta = "Arcebispo de Aachen", opcao1 = "Arcebispo de Mainz", opcao2 = "Arcebispo de Trier"),
                Pergunta(tema = 3, pergunta = "Qual foi o período conhecido como a Era dos Descobrimentos e quais exploradores se destacaram nesse período?", respostaCerta = "séculos XV e XVI, exploradores destacados Vasco da Gama e Cristóvão Colombo", opcao1 = "Século XVII, exploradores destacados incluíram Marco Polo e Genghis Khan", opcao2 = "Renascimento, exploradores notáveis foram Hernán Cortés e Moctezuma"),
                Pergunta(tema = 3, pergunta = "Quem foi o líder militar e político que desempenhou um papel fundamental na independência da Índia?", respostaCerta = "Mahatma Gandhi", opcao1 = "Mao Zedong", opcao2 = "Subhas Chandra Bose"),
                Pergunta(tema = 3, pergunta = "Em que ano a Primeira Guerra Mundial começou e qual foi a causa imediata do conflito?", respostaCerta = "1914, Assassinato do Arquiduque Francisco Ferdinando", opcao1 = "1910, causada por disputas territoriais na América Latina", opcao2 = "1939, causada por conflitos religiosos na Europa"),
                Pergunta(tema = 3, pergunta = "Qual foi a civilização antiga que construiu as pirâmides em Giza?", respostaCerta = "Egípcios", opcao1 = "Império Persa", opcao2 = "Império Romano"),
                Pergunta(tema = 3, pergunta = "Quem foi o primeiro presidente dos Estados Unidos?", respostaCerta = "George Washington", opcao1 = "Benjamin Franklin", opcao2 = "Thomas Jefferson"),
                Pergunta(tema = 3, pergunta = "Qual foi o evento que marcou o fim da Idade Média na Europa?", respostaCerta = "Renascimento", opcao1 = "A Grande Fome", opcao2 = "A Peste Negra"),
                Pergunta(tema = 3, pergunta = "Quem foi o líder da Revolução Cubana em 1959?", respostaCerta = "Fidel Castro", opcao1 = "Che Guevara", opcao2 = "Fulgencio Batista"),
                Pergunta(tema = 3, pergunta = "Qual era o nome do navio em que Cristóvão Colombo chegou às Américas em 1492?", respostaCerta = "Santa Maria", opcao1 = "Pinta", opcao2 = "La Niña"),
                Pergunta(tema = 3, pergunta = "Quem foi o líder político sul-africano que desempenhou um papel fundamental no fim do apartheid?", respostaCerta = "Nelson Mandela", opcao1 = "Winston Churchill", opcao2 = "Mao Zedong"),
                Pergunta(tema = 3, pergunta = "Desde George Washington, que entre 1789 e 1797 foi o primeiro presidente dos Estados Unidos da América, os americanos contam os chefes de Estado. Que posição ocupa Barack Obama?", respostaCerta = "É o 44º presidente.", opcao1 = "É o 43º presidente.", opcao2 = "É o 42º presidente."),
                Pergunta(tema = 3, pergunta = "Qual foi a civilização antiga que criou a Lei de Hamurabi, um dos conjuntos mais antigos de leis conhecidos?", respostaCerta = "Babilônia", opcao1 = "Egípcios", opcao2 = "Sumérios"),
                Pergunta(tema = 3, pergunta = "Qual foi o evento que marcou o início da Revolução Industrial?", respostaCerta = "Invenção da máquina a vapor", opcao1 = "Revolução Francesa", opcao2 = "Descobrimento da América"),
                Pergunta(tema = 3, pergunta = "Quem foi o líder da Revolução Russa de 1917?", respostaCerta = "Vladimir Lenin", opcao1 = "Joseph Stalin", opcao2 = "Leon Trotsky"),
                Pergunta(tema = 3, pergunta = "Qual foi o tratado que encerrou oficialmente a Primeira Guerra Mundial em 1919?", respostaCerta = "Tratado de Versalhes", opcao1 = "Tratado de Tordesilhas", opcao2 = "Tratado de Varsóvia"),
                Pergunta(tema = 4, pergunta = "O ouvido é um órgão complexo formado por ossículos minúsculos. Como se chama um deles?", respostaCerta = "Estribo", opcao1 = "Sela", opcao2 = "Bridão"),
                Pergunta(tema = 4, pergunta = "As diferentes estrelas diferem em tamanho e intensidade de luz, daí que tenham nomes especiais. Qual destes tipos de estrelas não existe?", respostaCerta = "Gigante Verde", opcao1 = "Gigante Vermelha", opcao2 = "Anã Castanha"),
                Pergunta(tema = 4, pergunta = "Qual é a ciência que estuda a vivência e os comportamentos do ser humano?", respostaCerta = "Psicologia", opcao1 = "Psiquiatria", opcao2 = "Antropologia"),
                Pergunta(tema = 4, pergunta = "Quem desenvolveu a teoria da relatividade?", respostaCerta = "Albert Einstein", opcao1 = "Isaac Newton", opcao2 = "Aristóteles"),
                Pergunta(tema = 4, pergunta = "Qual é o elemento mais abundante na crosta terrestre?", respostaCerta = "Oxigênio", opcao1 = "Ouro", opcao2 = "Ferro"),
                Pergunta(tema = 4, pergunta = "Quem é creditado pela criação da tabela periódica?", respostaCerta = "Dmitri Mendeleev", opcao1 = "Marie Curie", opcao2 = "Albert Einstein"),
                Pergunta(tema = 4, pergunta = "O que é um átomo?", respostaCerta = "A menor unidade de um elemento químico.", opcao1 = "Pequena partícula de luz", opcao2 = "Unidade de medida de temperatura"),
                Pergunta(tema = 4, pergunta = "Quem é considerado o pai da teoria da evolução?", respostaCerta = "Charles Darwin", opcao1 = "Isaac Newton", opcao2 = "Marie Curie"),
                Pergunta(tema = 4, pergunta = "O que é a terceira lei de Newton?", respostaCerta = "Lei da Ação e Reação", opcao1 = "Lei da Gravidade", opcao2 = "Lei da Inércia"),
                Pergunta(tema = 4, pergunta = "O que significa a sigla DNA?", respostaCerta = "Ácido Desoxirribonucleico", opcao1 = "Doença Neurodegenerativa Avançada", opcao2 = "Ácido Desoxigenado"),
                Pergunta(tema = 4, pergunta = "Qual é o símbolo químico para o ouro?", respostaCerta = "Au", opcao1 = "Ag", opcao2 = "Fe"),
                Pergunta(tema = 4, pergunta = "O que é a teoria do Big Bang?", respostaCerta = "Explicação científica para a origem do universo", opcao1 = "Uma teoria que postula a existência de vida em outros planetas", opcao2 = "Uma teoria que afirma que a Terra é plana"),
                Pergunta(tema = 4, pergunta = "Quem é considerado o pai da psicanálise?", respostaCerta = "Sigmund Freud", opcao1 = "Carl Jung", opcao2 = "Albert Einstein"),
                Pergunta(tema = 4, pergunta = "Qual é o planeta mais próximo do Sol no nosso sistema solar?", respostaCerta = "Mercúrio", opcao1 = "Vênus", opcao2 = "Marte"),
                Pergunta(tema = 4, pergunta = "Quem formulou a lei da gravidade?", respostaCerta = "Isaac Newton", opcao1 = "Marie Curie", opcao2 = "Charles Darwin"),
                Pergunta(tema = 5, pergunta = "Em 2004, Michael Schumacher sagrou-se campeão mundial de Fórmula 1..", respostaCerta = "… pela sétima vez", opcao1 = "… pela quinta vez", opcao2 = "… pela nona vez"),
                Pergunta(tema = 5, pergunta = "Quem é conhecido como 'The Greatest' no boxe e é considerado um dos maiores pugilistas de todos os tempos?", respostaCerta = "Muhammad Ali", opcao1 = "Mike Tyson", opcao2 = "Floyd Mayweather Jr."),
                Pergunta(tema = 5, pergunta = "Em que desporto é concedida a Bola de Ouro ao melhor jogador do mundo?", respostaCerta = "Futebol", opcao1 = "Tênis", opcao2 = "Basquete"),
                Pergunta(tema = 5, pergunta = "Qual país sediou os Jogos Olímpicos de Verão em 2016?", respostaCerta = "Brasil", opcao1 = "China", opcao2 = "Rússia"),
                Pergunta(tema = 5, pergunta = "Quem é o jogador de basquete comumente chamado de King James?", respostaCerta = "LeBron James", opcao1 = "Kobe Bryant", opcao2 = "Kevin Durant"),
                Pergunta(tema = 5, pergunta = "Em que esporte o termo hat-trick é frequentemente usado?", respostaCerta = "Futebol", opcao1 = "Golfe", opcao2 = "Tênis"),
                Pergunta(tema = 5, pergunta = "Qual é o desporto principal nos Jogos Olímpicos de Inverno?", respostaCerta = "Esqui", opcao1 = "Vela", opcao2 = "Natação"),
                Pergunta(tema = 5, pergunta = "Quem detém o recorde de mais medalhas de ouro olímpicas na história?", respostaCerta = "Michael Phelps", opcao1 = "Usain Bolt", opcao2 = "Serena Williams"),
                Pergunta(tema = 5, pergunta = "Qual é o desporto mais popular no mundo em termos de espectadores?", respostaCerta = "Futebol", opcao1 = "Cricket", opcao2 = "Futebol Americano"),
                Pergunta(tema = 5, pergunta = "Quem é o maior artilheiro da história da seleção brasileira de futebol?", respostaCerta = "Pelé", opcao1 = "Zico", opcao2 = "Kaká"),
                Pergunta(tema = 5, pergunta = "Em que desporto o termo grand slam é comumente usado?", respostaCerta = "Tênis", opcao1 = "Golfe", opcao2 = "Críquete"),
                Pergunta(tema = 5, pergunta = "Qual país é famoso por sua equipe de rugby, chamada All Blacks?", respostaCerta = "Nova Zelândia", opcao1 = "Austrália", opcao2 = "Inglaterra"),
                Pergunta(tema = 5, pergunta = "Quem é o atual campeão da NBA (2022)?", respostaCerta = "Milwaukee Bucks", opcao1 = "Golden State Warriors", opcao2 = "Los Angeles Lakers"),
                Pergunta(tema = 5, pergunta = "O que significa a sigla MMA, relacionada a desportos?", respostaCerta = "Artes Marciais Mistas", opcao1 = "Movimento de Modalidades Atléticas", opcao2 = "Máxima Manifestação Atlética")
            )
            perguntaDao.insertAll(*perguntas)
        }
    }
}
