package com.example.tentativa.Questions

import com.example.tentativa.QuestionEntity

val geographyQuestions = listOf(
    QuestionEntity(
        theme = "Geografia",
        question = "As cataratas do Niágara incluem-se entre as quedas de água mais famosas do mundo. Situadas no Estado de Nova lorque, estas cataratas ficam entre dois lagos enormes. Como se chamam os lagos?",
        correctAnswer = "Lago Erie e o lago Ontário",
        answers = listOf("Lago Erie e o lago Ontário", "Lago Erie e lago Superior", "Lago Erie e o lago Michigan")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Qual é o maior rio do mundo em volume de água?",
        correctAnswer = "Rio Amazonas",
        answers = listOf("Rio Nilo", "Rio Amazonas", "Rio Yangtzé")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Quais são os cinco maiores países do mundo em termos de área territorial?",
        correctAnswer = "Rússia, Canadá, Estados Unidos, China e Brasil",
        answers = listOf("Rússia, Canadá, Estados Unidos, China e Brasil", "Rússia, Brasil, Índia, China, Estados Unidos", "Canadá, Austrália, Estados Unidos, China, Índia", "Rússia, Canadá, Estados Unidos, China, Brasil")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Em que continente está localizado o Deserto do Saara?",
        correctAnswer = "África",
        answers = listOf("África", "América do Sul", "Ásia")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Qual é o ponto mais baixo da Terra, localizado na Fossa das Marianas?",
        correctAnswer = "Challenger Deep",
        answers = listOf("Abismo do Desespero", "Vale das Sombras", "Precipício Profundo", "Challenger Deep")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Quais são os três maiores rios do mundo em termos de volume de água?",
        correctAnswer = "Amazonas, Nilo e Yangtzé",
        answers = listOf("Rio Nilo, Rio Amazonas, Rio Tâmisa", "Rio Mississippi, Rio Ganges, Rio Amur", "Rio Yangtzé, Rio Colorado, Rio Danúbio", "Amazonas, Nilo e Yangtzé")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Qual é a capital do Canadá?",
        correctAnswer = "Ottawa",
        answers = listOf("Vancouver", "Toronto", "Montreal", "Ottawa")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Em que continente está localizado o Monte Kilimanjaro?",
        correctAnswer = "África",
        answers = listOf("Ásia", "América do Sul", "Europa", "África")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Quais são os cinco oceanos da Terra?",
        correctAnswer = "Pacífico, Atlântico, Índico, Antártico e Ártico",
        answers = listOf("Pacífico, Atlântico, Índico, Mar Mediterrâneo, Mar do Norte", "Mar de Coral, Mar de Bering, Oceano Antártico, Mar de Aral, Oceano Ártico", "Pacífico, Atlântico, Índico, Antártico, Mar Cáspio", "Pacífico, Atlântico, Índico, Antártico e Ártico")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Qual é o país mais populoso do mundo?",
        correctAnswer = "China",
        answers = listOf("Índia", "Estados Unidos", "Brasil", "China")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Onde está localizado o Deserto do Atacama, considerado o deserto mais seco do mundo?",
        correctAnswer = "Chile",
        answers = listOf("Austrália", "Rússia", "Chile")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Quais são os quatro pontos cardeais?",
        correctAnswer = "Norte, Sul, Leste e Oeste",
        answers = listOf("Norte, Oeste, Sul, Leste", "Leste, Norte, Oeste, Sul", "Nordeste, Sudoeste, Noroeste, Sudeste", "Norte, Sul, Leste e Oeste")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Qual é o maior arquipélago do mundo em termos de número de ilhas?",
        correctAnswer = "Indonésia",
        answers = listOf("Havaí", "Japão", "Indonésia")
    ),
    QuestionEntity(
        theme = "Geografia",
        question = "Quais são os dois países que compartilham a ilha de Hispaniola no Caribe?",
        correctAnswer = "Haiti e República Dominicana",
        answers = listOf("Cuba e Jamaica", "Haiti e República Dominicana", "Porto Rico e Bahamas")
    )
)
