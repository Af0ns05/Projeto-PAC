/*package com.example.tentativa

class QuestionRepository(private val questionDao: QuestionDao) {
    fun getQuestionsByTheme(theme: String): List<QuestionEntity> {
        return questionDao.getQuestionsByTheme(theme)
    }

    suspend fun insertQuestion(question: QuestionEntity) {
        questionDao.insertQuestion(question)
    }

    suspend fun insertQuestions(questions: List<QuestionEntity>) {
        questionDao.insertQuestions(questions)
    }
}

class PlayerScoreRepository(private val playerScoreDao: PlayerScoreDao) {
    fun getAllScores(): List<PlayerScoreEntity> {
        return playerScoreDao.getAllScores()
    }

    suspend fun insertPlayerScore(score: PlayerScoreEntity) {
        playerScoreDao.insertPlayerScore(score)
    }
}
*/