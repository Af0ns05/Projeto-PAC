package com.example.tentativa.dao

import androidx.room.*
import com.example.tentativa.entity.Pergunta

@Dao
interface PerguntaDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(pergunta: Pergunta)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(vararg perguntas: Pergunta)

    @Update
    fun update(pergunta: Pergunta)

    @Delete
    fun delete(pergunta: Pergunta)

    @Query("SELECT * FROM perguntas WHERE tema = :tema ORDER BY RANDOM() LIMIT 10")
    fun getRandomPerguntasByTema(tema: Int): List<Pergunta>
}
