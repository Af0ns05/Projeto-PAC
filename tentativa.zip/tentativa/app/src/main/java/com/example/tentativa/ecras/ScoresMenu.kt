package com.example.tentativa.ecras

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tentativa.R
import com.example.tentativa.database.AppDatabase
import com.example.tentativa.entity.Pontuacao
import kotlinx.coroutines.launch
import com.example.tentativa.viewmodel.MainViewModel

@Composable
fun ScoresMenu(viewModel: MainViewModel, onBack: () -> Unit) {
    val scores by viewModel.pontuacoes.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.loadPontuacoes()
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.fundopng), // Replace with your image resource ID
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Pontuações", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            scores.forEach { score ->
                ScoreRow(score.nome, painterResource(id = R.drawable.ic_art), "${score.pontuacao}/10") // Change icon based on theme
            }
            QuizButton("Voltar", painterResource(id = R.drawable.ic_back), onClick = onBack)
        }
    }
}



@Composable
fun ScoreRow(name: String, categoryIcon: Painter, score: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .height(50.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .background(Color(0xFF757575).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(8.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(name, fontSize = 18.sp, color = Color.White)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .background(Color(0xFF757575).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            if (name.isNotEmpty() && score.isNotEmpty()) {
                Image(painter = categoryIcon, contentDescription = null, modifier = Modifier.size(24.dp))
            }
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .background(Color(0xFF757575).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(8.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Text(score, fontSize = 18.sp, color = Color.Black)
        }
    }
}