package com.example.tentativa.Questions

import com.example.tentativa.QuestionEntity

val scienceQuestions = listOf(
    QuestionEntity(
        theme = "Ciências",
        question = "O ouvido é um orgão complexo formado por occículos minúsculos. Como se chama um deles?",
        correctAnswer = "Estribo",
        answers = listOf("Sela", "Bridão", "Estribo")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "As diferentes estrelas diferem em tamanho e intensidade de luz, daí que tenham nomes especiais. Qual destes tipos de estrelas não existe?",
        correctAnswer = "Gigante Verde",
        answers = listOf("Gigante Verde", "Gigante Vermelha", "Anã Castanha")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "Qual é a ciência que estuda a vivência e o comportamento do ser humano?",
        correctAnswer = "Psicologia",
        answers = listOf("Psiquiatria", "Antropologia", "Psicologia")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "O que é a teoria da relatividade e quem a desenvolveu?",
        correctAnswer = "Albert Einstein",
        answers = listOf("Desenvolvida por Isaac Newton", "Trata da lei da gravidade apenas", "Uma teoria sobre eletricidade", "Albert Einstein")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "Qual é o elemento mais abundante na crosta terrestre?",
        correctAnswer = "Oxigênio",
        answers = listOf("Ouro", "Ferro", "Alumínio", "Oxigênio")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "O que é a tabela periódica e quem é creditado por sua criação?",
        correctAnswer = "Dmitri Mendeleev",
        answers = listOf("Criada por Marie Curie", "Uma lista de elementos químicos em ordem alfabética", "Desenvolvida por Dmitri Mendeleev")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "O que é um átomo?",
        correctAnswer = "A menor unidade de um elemento químico",
        answers = listOf("Pequena partícula de luz", "Unidade de medida de temperatura", "Unidade básica de matéria", "A menor unidade de um elemento químico")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "Quem é considerado o pai da teoria da evolução?",
        correctAnswer = "Charles Darwin",
        answers = listOf("Isaac Newton", "Marie Curie", "Charles Darwin")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "O que é a terceira lei de Newton?",
        correctAnswer = "Para cada ação, há uma reação igual e oposta",
        answers = listOf("Lei da Gravidade", "Lei da Inércia", "Lei da Ação e Reação")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "O que significa a sigla DNA?",
        correctAnswer = "Ácido Desoxirribonucleico",
        answers = listOf("Doença Neurodegenerativa Avançada", "Ácido Desoxigenado", "Ácido Desoxirribonucleico")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "Qual é o símbolo químico para o ouro?",
        correctAnswer = "Au",
        answers = listOf("Ag", "Au", "Fe")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "Qual é o componente mais abundante na atmosfera da Terra?",
        correctAnswer = "Nitrogênio",
        answers = listOf("Oxigênio", "Nitrogênio", "Carbono")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "O que é a teoria do Big Bang?",
        correctAnswer = "Explicação científica para a origem do universo",
        answers = listOf("Uma teoria sobre a origem do chocolate", "Uma teoria que postula a existência de vida em outros planetas", "Uma teoria que afirma que a Terra é plana", "Explicação científica para a origem do universo")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "Quem é considerado o pai da psicanálise?",
        correctAnswer = "Sigmund Freud",
        answers = listOf("Carl Jung", "Albert Einstein", "Sigmund Freud")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "Qual é o planeta mais próximo do Sol no nosso sistema solar?",
        correctAnswer = "Mercúrio",
        answers = listOf("Vênus", "Marte", "Júpiter", "Mercúrio")
    ),
    QuestionEntity(
        theme = "Ciências",
        question = "O que é a lei da gravidade e quem a formulou?",
        correctAnswer = "Lei da gravitação universal de Newton",
        answers = listOf("Formulada por Marie Curie", "Uma teoria que nega a existência da gravidade", "Lei da gravitação universal de Newton")
    )
)
