package com.example.tentativa.ecras

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tentativa.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun QuizScreen(
    viewModel: MainViewModel = viewModel(),
    selectedTheme: String,
    playerName: String,
    onBack: () -> Unit,
    onFinish: (Int) -> Unit
) {
    var currentQuestionIndex by remember { mutableStateOf(0) }
    var correctAnswers by remember { mutableStateOf(0) }
    val questions by viewModel.perguntas.collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(selectedTheme) {
        coroutineScope.launch {
            Log.d("QuizScreen", "Loading questions for theme: $selectedTheme")
            viewModel.loadPerguntasByTema(getThemeNumber(selectedTheme))
        }
    }

    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Question ${currentQuestionIndex + 1} of ${questions.size}")
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = questions[currentQuestionIndex].pergunta)
            Spacer(modifier = Modifier.height(16.dp))

            listOf(
                questions[currentQuestionIndex].opcao1,
                questions[currentQuestionIndex].opcao2,
                questions[currentQuestionIndex].respostaCerta
            ).shuffled().forEach { option ->
                Button(
                    onClick = {
                        if (option == questions[currentQuestionIndex].respostaCerta) correctAnswers++
                        if (currentQuestionIndex < questions.size - 1) {
                            currentQuestionIndex++
                        } else {
                            onFinish(correctAnswers)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = option)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                Text(text = "Voltar")
            }
        }
    }
}

fun getThemeNumber(selectedTheme: String): Int {
    return when (selectedTheme) {
        "Tema 1" -> 1
        "Tema 2" -> 2
        else -> 0
    }
}
