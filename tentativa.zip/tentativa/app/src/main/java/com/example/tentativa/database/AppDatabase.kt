package com.example.tentativa.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.tentativa.dao.PerguntaDao
import com.example.tentativa.dao.PontuacaoDao
import com.example.tentativa.dao.SugestaoDao
import com.example.tentativa.entity.Pergunta
import com.example.tentativa.entity.Pontuacao
import com.example.tentativa.entity.Sugestao

@Database(entities = [Pergunta::class, Pontuacao::class, Sugestao::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun perguntaDao(): PerguntaDao
    abstract fun pontuacaoDao(): PontuacaoDao
    abstract fun sugestaoDao(): SugestaoDao
}
