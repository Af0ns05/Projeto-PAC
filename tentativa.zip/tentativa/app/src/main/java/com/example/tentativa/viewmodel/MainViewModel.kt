package com.example.tentativa.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tentativa.database.AppDatabase
import com.example.tentativa.entity.Pergunta
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(private val database: AppDatabase) : ViewModel() {

    private val _perguntas = MutableStateFlow<List<Pergunta>>(emptyList())
    val perguntas: StateFlow<List<Pergunta>> = _perguntas

    fun loadPerguntasByTema(themeNumber: Int) {
        viewModelScope.launch {
            _perguntas.value = database.perguntaDao().getRandomPerguntasByTema(themeNumber)
        }
    }
}
