package com.example.tentativa.ecras

import androidx.compose.runtime.Composable
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.text.input.TextFieldValue
import com.example.tentativa.viewmodel.MainViewModel

@Composable
fun MainScreen(viewModel: MainViewModel, onExit: () -> Unit) {
    val currentScreen by viewModel.currentScreen.observeAsState()
    val playerName by viewModel.playerName.observeAsState(TextFieldValue(""))

    when (currentScreen) {
        "EnterNameScreen" -> EnterNameScreen(
            selectedTheme = "Default Theme",
            onBack = { viewModel.onBack() },
            onProceed = { name ->
                viewModel.setPlayerName(name)
                viewModel.proceedToQuiz()
            }
        )
        "QuizScreen" -> QuizScreen(
            playerName = playerName.text,
            selectedTheme = "Default Theme",
            onBack = { viewModel.onBack() },
            onFinish = { score ->
                // Handle quiz completion, e.g., show score or save to database
            }
        )
        else -> EnterNameScreen(
            selectedTheme = "Default Theme",
            onBack = { viewModel.onBack() },
            onProceed = { name ->
                viewModel.setPlayerName(name)
                viewModel.proceedToQuiz()
            }
        )
    }
}
