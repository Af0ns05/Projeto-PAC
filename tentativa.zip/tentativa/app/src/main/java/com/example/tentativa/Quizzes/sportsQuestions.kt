package com.example.tentativa.Questions

import com.example.tentativa.QuestionEntity

val sportsQuestions = listOf(
    QuestionEntity(
        theme = "Desporto",
        question = "Em 2004 Michael Schumacher sagrou-se campeão mundial de Fórmula 1..",
        correctAnswer = "… pela sétima vez",
        answers = listOf("… pela sétima vez", "… pela quinta vez", "… pela nona vez")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Quem é conhecido como 'The Greatest' no boxe e é considerado um dos maiores pugilistas de todos os tempos?",
        correctAnswer = "Muhammad Ali",
        answers = listOf("Mike Tyson", "Floyd Mayweather Jr.", "Manny Pacquiao", "Muhammad Ali")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Em que esporte é concedida a 'Bola de Ouro' ao melhor jogador do mundo?",
        correctAnswer = "Futebol",
        answers = listOf("Tênis", "Basquete", "Rugby", "Futebol")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Qual país sediou os Jogos Olímpicos de Verão em 2016?",
        correctAnswer = "Brasil",
        answers = listOf("China", "Rússia", "Japão", "Brasil")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Quem é o jogador de basquete comumente chamado de 'King James'?",
        correctAnswer = "LeBron James",
        answers = listOf("Kobe Bryant", "Kevin Durant", "Stephen Curry", "LeBron James")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Em que esporte o termo 'hat-trick' é frequentemente usado?",
        correctAnswer = "Futebol",
        answers = listOf("Golfe", "Tênis", "Críquete", "Futebol")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Qual é o esporte principal nos Jogos Olímpicos de Inverno?",
        correctAnswer = "Esqui",
        answers = listOf("Vela", "Esqui Alpino", "Natação", "Esqui")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Quem detém o recorde de mais medalhas de ouro olímpicas na história?",
        correctAnswer = "Michael Phelps",
        answers = listOf("Usain Bolt", "Michael Phelps", "Serena Williams")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Qual é o desporto mais popular no mundo em termos de espectadores?",
        correctAnswer = "Futebol",
        answers = listOf("Cricket", "Basquete", "Futebol Americano", "Futebol")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Quem é o maior artilheiro da história da seleção brasileira de futebol?",
        correctAnswer = "Pelé",
        answers = listOf("Zico", "Kaká", "Neymar", "Pelé")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Em que esporte o termo 'grand slam' é comumente usado?",
        correctAnswer = "Tênis",
        answers = listOf("Tênis", "Golfe", "Críquete")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Qual país é famoso por sua equipe de rugby, chamada All Blacks?",
        correctAnswer = "Nova Zelândia",
        answers = listOf("Austrália", "África do Sul", "Inglaterra", "Nova Zelândia")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "Quem é o atual campeão da NBA (2022)?",
        correctAnswer = "Milwaukee Bucks",
        answers = listOf("Golden State Warriors", "Los Angeles Lakers", "Brooklyn Nets", "Milwaukee Bucks")
    ),
    QuestionEntity(
        theme = "Desporto",
        question = "O que significa a sigla MMA, relacionada a esportes?",
        correctAnswer = "Artes Marciais Mistas",
        answers = listOf("Movimento de Modalidades Atléticas", "Máxima Manifestação Atlética", "Artes Marciais Mistas")
    )
)
