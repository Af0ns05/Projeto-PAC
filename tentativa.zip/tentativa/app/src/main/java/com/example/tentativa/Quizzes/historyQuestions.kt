package com.example.tentativa.Questions

import com.example.tentativa.QuestionEntity

val historyQuestions = listOf(
    QuestionEntity(
        theme = "História",
        question = "Desde George Washington, que entre 1789 e 1797 foi o primeiro presidente dos Estados Unidos da América, os americanos contam os chefes de Estado. Que posição ocupa Barack Obama?",
        correctAnswer = "É o 44º presidente.",
        answers = listOf("É o 43º presidente.", "É o 42º presidente.", "É o 44º presidente.")
    ),
    QuestionEntity(
        theme = "História",
        question = "No período da Baixa Idade Média, os imperadores alemães eram nomeados por sete príncipes-eleitores. Qual destes bispos não fazia parte do grupo?",
        correctAnswer = "Arcebispo de Aachen",
        answers = listOf("Arcebispo de Mainz", "Arcebispo de Trier", "Arcebispo de Aachen")
    ),
    QuestionEntity(
        theme = "História",
        question = "Qual foi o período conhecido como a 'Era dos Descobrimentos' e quais exploradores se destacaram nesse período?",
        correctAnswer = "Era dos Descobrimentos (séculos XV e XVI) - Alguns exploradores notáveis incluem Vasco da Gama e Cristóvão Colombo.",
        answers = listOf(
            "Século XVII, exploradores destacados incluíram Marco Polo e Genghis Khan",
            "Renascimento, exploradores notáveis foram Hernán Cortés e Moctezuma",
            "Idade Média, exploradores notáveis foram Vasco da Gama e Fernão Mendes Pinto",
            "Era dos Descobrimentos (séculos XV e XVI) - Alguns exploradores notáveis incluem Vasco da Gama e Cristóvão Colombo."
        )
    ),
    QuestionEntity(
        theme = "História",
        question = "Quem foi o líder militar e político que desempenhou um papel fundamental na independência da Índia?",
        correctAnswer = "Mahatma Gandhi",
        answers = listOf("Mao Zedong", "Ho Chi Minh", "Subhas Chandra Bose", "Mahatma Gandhi")
    ),
    QuestionEntity(
        theme = "História",
        question = "Em que ano a Primeira Guerra Mundial começou e qual foi a causa imediata do conflito?",
        correctAnswer = "1914; Assassinato do Arquiduque Francisco Ferdinando",
        answers = listOf(
            "1910, causada por disputas territoriais na América Latina",
            "1939, causada por conflitos religiosos na Europa",
            "1914; Assassinato do Arquiduque Francisco Ferdinando"
        )
    ),
    QuestionEntity(
        theme = "História",
        question = "Qual foi a civilização antiga que construiu as pirâmides em Giza?",
        correctAnswer = "Egípcios",
        answers = listOf("Império Persa", "Império Romano", "Império Egípcio", "Egípcios")
    ),
    QuestionEntity(
        theme = "História",
        question = "Quem foi o primeiro presidente dos Estados Unidos?",
        correctAnswer = "George Washington",
        answers = listOf("Benjamin Franklin", "Thomas Jefferson", "John Adams", "George Washington")
    ),
    QuestionEntity(
        theme = "História",
        question = "Qual foi o evento que marcou o fim da Idade Média na Europa?",
        correctAnswer = "Renascimento",
        answers = listOf("A Grande Fome", "A Peste Negra", "A Renascença", "Renascimento")
    ),
    QuestionEntity(
        theme = "História",
        question = "Quem foi o líder da Revolução Cubana em 1959?",
        correctAnswer = "Fidel Castro",
        answers = listOf("Che Guevara", "Fulgencio Batista", "Fidel Castro")
    ),
    QuestionEntity(
        theme = "História",
        question = "Qual era o nome do navio em que Cristóvão Colombo chegou às Américas em 1492?",
        correctAnswer = "Santa Maria",
        answers = listOf("Santa Maria", "Pinta", "La Niña")
    ),
    QuestionEntity(
        theme = "História",
        question = "Quem foi o líder político sul-africano que desempenhou um papel fundamental no fim do apartheid?",
        correctAnswer = "Nelson Mandela",
        answers = listOf("Winston Churchill", "Nelson Mandela", "Mao Zedong")
    ),
    QuestionEntity(
        theme = "História",
        question = "Qual foi a civilização antiga que criou a Lei de Hamurabi, um dos conjuntos mais antigos de leis conhecidos?",
        correctAnswer = "Babilônia",
        answers = listOf("Egípcios", "Sumérios", "Babilônios")
    ),
    QuestionEntity(
        theme = "História",
        question = "Qual foi o evento que marcou o início da Revolução Industrial?",
        correctAnswer = "Invenção da máquina a vapor",
        answers = listOf("Invenção da máquina a vapor", "Revolução Francesa", "Descobrimento da América")
    ),
    QuestionEntity(
        theme = "História",
        question = "Quem foi o líder da Revolução Russa de 1917?",
        correctAnswer = "Vladimir Lenin",
        answers = listOf("Vladimir Lenin", "Joseph Stalin", "Leon Trotsky")
    ),
    QuestionEntity(
        theme = "História",
        question = "Qual foi o tratado que encerrou oficialmente a Primeira Guerra Mundial em 1919?",
        correctAnswer = "Tratado de Versalhes",
        answers = listOf("Tratado de Versalhes", "Tratado de Tordesilhas", "Tratado de Varsóvia")
    )
)
