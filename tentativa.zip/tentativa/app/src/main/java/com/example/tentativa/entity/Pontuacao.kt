package com.example.tentativa.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "pontuacoes",
    foreignKeys = [ForeignKey(
        entity = Pergunta::class,
        parentColumns = ["tema"],
        childColumns = ["tema"],
        onDelete = ForeignKey.CASCADE
    )]
)
data class Pontuacao(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "nome") val nome: String,
    @ColumnInfo(name = "tema") val tema: Int,
    @ColumnInfo(name = "pontuacao") val pontuacao: Int
)
