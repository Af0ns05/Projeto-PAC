package com.example.tentativa.dao

import androidx.room.*
import com.example.tentativa.entity.Pontuacao

@Dao
interface PontuacaoDao {
    @Insert
    fun insert(pontuacao: Pontuacao)

    @Update
    fun update(pontuacao: Pontuacao)

    @Delete
    fun delete(pontuacao: Pontuacao)

    @Query("SELECT * FROM pontuacoes")
    fun getAllPontuacoes(): List<Pontuacao>
}
