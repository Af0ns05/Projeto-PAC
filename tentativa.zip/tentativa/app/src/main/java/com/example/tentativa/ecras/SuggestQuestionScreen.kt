package com.example.tentativa.ecras

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tentativa.R
import com.example.tentativa.entity.Sugestao
import com.example.tentativa.viewmodel.MainViewModel

@Composable
fun SuggestQuestionScreen(viewModel: MainViewModel, onBack: () -> Unit, onBackToMenu: () -> Unit) {
    var selectedTheme by remember { mutableStateOf("Artes") }
    var questionText by remember { mutableStateOf(TextFieldValue("")) }
    var answerText by remember { mutableStateOf(TextFieldValue("")) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var showThankYouDialog by remember { mutableStateOf(false) }

    if (showThankYouDialog) {
        AlertDialog(
            onDismissRequest = { showThankYouDialog = false },
            title = { Text("Obrigado pela sua sugestão!") },
            text = { Text("Nós iremos rever e colocá-la.") },
            confirmButton = {
                Button(onClick = {
                    showThankYouDialog = false
                    onBackToMenu()
                }) {
                    Text("Voltar ao menu inicial")
                }
            }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.fundopng), // Replace with your image resource ID
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Sugerir Pergunta", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            Spacer(modifier = Modifier.height(16.dp))

            Box(modifier = Modifier.fillMaxWidth(0.8f)) {
                Button(onClick = { dropdownExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(selectedTheme)
                }
                DropdownMenu(
                    expanded = dropdownExpanded,
                    onDismissRequest = { dropdownExpanded = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    DropdownMenuItem(text = { Text("Artes") }, onClick = {
                        selectedTheme = "Artes"
                        dropdownExpanded = false
                    })
                    DropdownMenuItem(text = { Text("Geografia") }, onClick = {
                        selectedTheme = "Geografia"
                        dropdownExpanded = false
                    })
                    DropdownMenuItem(text = { Text("História") }, onClick = {
                        selectedTheme = "História"
                        dropdownExpanded = false
                    })
                    DropdownMenuItem(text = { Text("Ciências") }, onClick = {
                        selectedTheme = "Ciências"
                        dropdownExpanded = false
                    })
                    DropdownMenuItem(text = { Text("Desporto") }, onClick = {
                        selectedTheme = "Desporto"
                        dropdownExpanded = false
                    })
                }
            }

            TextField(
                value = questionText,
                onValueChange = { questionText = it },
                label = { Text("Digite a pergunta") },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(56.dp),
                singleLine = true
            )
            TextField(
                value = answerText,
                onValueChange = { answerText = it },
                label = { Text("Digite a resposta") },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(56.dp),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    viewModel.addSugestao(Sugestao(
                        tema = getThemeNumber(selectedTheme),
                        pergunta = questionText.text,
                        resposta = answerText.text
                    ))
                    showThankYouDialog = true
                },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF757575).copy(alpha = 0.5f))
            ) {
                Text("Submeter", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF757575).copy(alpha = 0.5f))
            ) {
                Text("Voltar", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

