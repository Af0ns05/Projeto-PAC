package com.example.tentativa.ecras

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tentativa.R

@Composable
fun QuizMenu(onBack: () -> Unit, onSelectTheme: (String) -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.fundopng), // Replace with your image resource ID
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Temas", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            QuizButton("Artes", painterResource(id = R.drawable.ic_art)) { onSelectTheme("Artes") }
            QuizButton("Geografia", painterResource(id = R.drawable.ic_geography)) { onSelectTheme("Geografia") }
            QuizButton("História", painterResource(id = R.drawable.ic_history)) { onSelectTheme("História") }
            QuizButton("Ciências", painterResource(id = R.drawable.ic_science)) { onSelectTheme("Ciências") }
            QuizButton("Desporto", painterResource(id = R.drawable.ic_sports)) { onSelectTheme("Desporto") }
            QuizButton("Aleatório", painterResource(id = R.drawable.ic_random)) { onSelectTheme("Aleatório") }
            QuizButton("Voltar", painterResource(id = R.drawable.ic_back), onClick = onBack)
        }
    }
}