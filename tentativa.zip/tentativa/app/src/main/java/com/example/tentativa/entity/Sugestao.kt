package com.example.tentativa.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sugestao")
data class Sugestao(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "tema") val tema: Int,
    @ColumnInfo(name = "pergunta") val pergunta: String,
    @ColumnInfo(name = "resposta") val resposta: String
)
