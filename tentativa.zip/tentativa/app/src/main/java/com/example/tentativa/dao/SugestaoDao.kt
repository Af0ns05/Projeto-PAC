package com.example.tentativa.dao

import androidx.room.*
import com.example.tentativa.entity.Sugestao

@Dao
interface SugestaoDao {
    @Insert
    fun insert(sugestao: Sugestao)

    @Update
    fun update(sugestao: Sugestao)

    @Delete
    fun delete(sugestao: Sugestao)

    @Query("SELECT * FROM sugestao")
    fun getAllSugestoes(): List<Sugestao>
}
