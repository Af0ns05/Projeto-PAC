package com.example.tentativa.Questions

import com.example.tentativa.QuestionEntity

val artQuestions = listOf(
    QuestionEntity(
        theme = "Arte",
        question = "Quem foi o pintor renascentista conhecido por suas obras 'O Nascimento de Vênus' e 'A Primavera'?",
        correctAnswer = "Sandro Botticelli",
        answers = listOf("Michelangelo", "Rafael Sanzio", "Vincent van Gogh", "Sandro Botticelli")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Qual é o nome da pintura que retrata uma mulher sorrindo com uma expressão enigmática, pintada por Leonardo da Vinci?",
        correctAnswer = "Mona Lisa",
        answers = listOf("A Dama com Arminho", "A Última Ceia", "Mona Lisa")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Quem foi o arquiteto responsável pela construção da Torre Eiffel em Paris?",
        correctAnswer = "Gustave Eiffel",
        answers = listOf("Frank Lloyd Wright", "Antoni Gaudí", "Gustave Eiffel")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Quem pintou 'A Noite Estrelada'?",
        correctAnswer = "Vincent van Gogh",
        answers = listOf("Pablo Picasso", "Claude Monet", "Vincent van Gogh")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Qual é a forma de arte que usa movimento como meio de expressão?",
        correctAnswer = "Dança",
        answers = listOf("Surrealismo", "Expressionismo", "Pop art", "Dança")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Quem escreveu a peça de teatro 'Romeu e Julieta'?",
        correctAnswer = "William Shakespeare",
        answers = listOf("William Shakespeare", "Dante Alighieri", "Miguel de Cervantes")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Qual movimento artístico foi caracterizado por formas geométricas abstratas e uso de cores primárias?",
        correctAnswer = "Cubismo",
        answers = listOf("Renascimento", "Barroco", "Cubismo")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Quem é conhecido como o 'pai da pintura moderna'?",
        correctAnswer = "Paul Cézanne",
        answers = listOf("Leonardo da Vinci", "Donatello", "Michelangelo", "Paul Cézanne")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Quem é conhecido por suas esculturas em mármore, incluindo 'David' e 'Pietà'?",
        correctAnswer = "Michelangelo",
        answers = listOf("Vincent van Gogh", "Claude Monet", "Pablo Picasso", "Michelangelo")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Qual é o nome do estilo de arte que se originou na década de 1960 e apresenta obras de arte usando objetos do cotidiano?",
        correctAnswer = "Pop art",
        answers = listOf("Rococó", "Barroco", "Cubismo", "Pop art")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Quem foi o autor de 'Dom Quixote', frequentemente considerado o primeiro romance moderno?",
        correctAnswer = "Miguel de Cervantes",
        answers = listOf("William Shakespeare", "Jane Austen", "Charles Dickens", "Miguel de Cervantes")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Qual é o nome da técnica artística que envolve cortar e colar pedaços de papel para criar uma imagem?",
        correctAnswer = "Colagem",
        answers = listOf("Aquarela", "Gravura", "Stencil", "Colagem")
    ),
    QuestionEntity(
        theme = "Arte",
        question = "Quem foi o fundador do surrealismo, conhecido por suas obras de arte oníricas e estranhas?",
        correctAnswer = "André Breton",
        answers = listOf("Vincent van Gogh", "Pablo Picasso", "Salvador Dalí", "André Breton")
    )
)
