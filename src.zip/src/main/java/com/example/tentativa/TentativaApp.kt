package com.example.tentativa

import android.app.Application
import androidx.room.Room
import com.example.tentativa.Questions.artQuestions
import com.example.tentativa.database.AppDatabase
import com.example.tentativa.entity.Pergunta
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TentativaApp : Application() {

    companion object {
        lateinit var database: AppDatabase
    }

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "tentativa-database"
        ).build()

        // Load initial questions into the database
        CoroutineScope(Dispatchers.IO).launch {
            loadInitialQuestions()
        }
    }

    private suspend fun loadInitialQuestions() {
        val questionDao = database.perguntaDao()
        artQuestions.forEach { question ->
            questionDao.insert(
                Pergunta(
                    tema = getThemeNumber(question.theme),
                    pergunta = question.question,
                    respostaCerta = question.correctAnswer,
                    opcao1 = question.answers[0],
                    opcao2 = question.answers[1]
                )
            )
        }
    }

    private fun getThemeNumber(theme: String): Int {
        return when (theme) {
            "Arte" -> 1
            // Add other themes here
            else -> 0
        }
    }
}
