package com.example.tentativa.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "perguntas",
    indices = [Index(value = ["tema"], unique = true)]
)
data class Pergunta(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @ColumnInfo(name = "tema") val tema: Int,
    @ColumnInfo(name = "pergunta") val pergunta: String,
    @ColumnInfo(name = "resposta_certa") val respostaCerta: String,
    @ColumnInfo(name = "opcao1") val opcao1: String,
    @ColumnInfo(name = "opcao2") val opcao2: String
)
