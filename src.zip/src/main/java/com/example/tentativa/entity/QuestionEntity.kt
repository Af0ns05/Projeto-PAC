package com.example.tentativa

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "questions")
data class QuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val theme: String,
    val question: String,
    val correctAnswer: String,
    val answers: List<String> // Você pode converter isso para um tipo que Room suporte, como String
)

@Entity(tableName = "player_scores")
data class PlayerScoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val playerName: String,
    val theme: String,
    val score: Int
)

