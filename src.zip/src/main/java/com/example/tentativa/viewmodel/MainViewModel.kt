package com.example.tentativa.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tentativa.database.AppDatabase
import com.example.tentativa.ecras.Question
import com.example.tentativa.entity.Pergunta
import com.example.tentativa.entity.Pontuacao
import com.example.tentativa.entity.Sugestao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val database: AppDatabase) : ViewModel() {

    private val _perguntas = MutableStateFlow<List<Question>>(emptyList())
    val perguntas: StateFlow<List<Question>> = _perguntas

    private val _pontuacoes = MutableStateFlow<List<Pontuacao>>(emptyList())
    val pontuacoes: StateFlow<List<Pontuacao>> = _pontuacoes

    private val _sugestoes = MutableStateFlow<List<Sugestao>>(emptyList())
    val sugestoes: StateFlow<List<Sugestao>> = _sugestoes

    fun loadPerguntasByTema(tema: Int) {
        viewModelScope.launch {
            try {
                val perguntas = withContext(Dispatchers.IO) {
                    database.perguntaDao().getRandomPerguntasByTema(tema)
                }
                val questionList = perguntas.map { pergunta ->
                    Question(
                        pergunta = pergunta.pergunta,
                        respostas = listOf(pergunta.respostaCerta, pergunta.opcao1, pergunta.opcao2).shuffled(),
                        respostaCerta = pergunta.respostaCerta
                    )
                }
                _perguntas.value = questionList
            } catch (e: Exception) {
                // Handle exceptions, log errors
                e.printStackTrace()
            }
        }
    }

    fun loadPontuacoes() {
        viewModelScope.launch {
            _pontuacoes.value = database.pontuacaoDao().getAllPontuacoes()
        }
    }

    fun loadSugestoes() {
        viewModelScope.launch {
            _sugestoes.value = database.sugestaoDao().getAllSugestoes()
        }
    }

    fun addSugestao(sugestao: Sugestao) {
        viewModelScope.launch {
            database.sugestaoDao().insert(sugestao)
            loadSugestoes()
        }
    }

    fun addPontuacao(pontuacao: Pontuacao) {
        viewModelScope.launch {
            database.pontuacaoDao().insert(pontuacao)
            loadPontuacoes()
        }
    }
}
