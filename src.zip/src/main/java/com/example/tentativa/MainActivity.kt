package com.example.tentativa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.tentativa.database.AppDatabase
import com.example.tentativa.ecras.MainScreen
import com.example.tentativa.ui.theme.TentativaTheme
import com.example.tentativa.viewmodel.MainViewModel
import com.example.tentativa.viewmodel.MainViewModelFactory

class MainActivity : ComponentActivity() {
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "quiz-database"
        ).build()

        val viewModelFactory = MainViewModelFactory(database)
        val viewModel: MainViewModel by viewModels { viewModelFactory }

        setContent {
            TentativaTheme {
                MainScreen(
                    viewModel = viewModel,
                    onExit = { finish() } // Exit the application
                )
            }
        }
    }
}
