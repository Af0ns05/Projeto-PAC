package com.example.tentativa.ecras

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tentativa.R
import com.example.tentativa.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import android.util.Log

@Composable
fun QuizScreen(viewModel: MainViewModel, selectedTheme: String, playerName: String, onBack: () -> Unit, onFinish: (Int) -> Unit) {
    var currentQuestionIndex by remember { mutableStateOf(0) }
    var correctAnswers by remember { mutableStateOf(0) }
    val questions by viewModel.perguntas.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(selectedTheme) {
        coroutineScope.launch {
            Log.d("QuizScreen", "Loading questions for theme: $selectedTheme")
            viewModel.loadPerguntasByTema(getThemeNumber(selectedTheme))
        }
    }

    if (questions.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    } else {
        val currentQuestion = questions[currentQuestionIndex]

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = selectedTheme,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
                Text(
                    text = "Pergunta ${currentQuestionIndex + 1} de 10",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
                Spacer(modifier = Modifier.height(16.dp))
                InfoText(currentQuestion.pergunta)
                currentQuestion.respostas.forEach { answer ->
                    QuizAnswerButton(text = answer) {
                        if (answer == currentQuestion.respostaCerta) {
                            correctAnswers++
                        }
                        if (currentQuestionIndex < questions.size - 1) {
                            currentQuestionIndex++
                        } else {
                            onFinish(correctAnswers)
                        }
                    }
                }
                QuizButton(
                    text = "Voltar",
                    icon = painterResource(id = R.drawable.ic_back),
                    onClick = onBack
                )
            }
        }
    }
}

fun getThemeNumber(selectedTheme: String): Int {
    return when (selectedTheme) {
        "Arte" -> 1
        // Add other themes here
        else -> 0
    }
}

data class Question(
    val pergunta: String,
    val respostas: List<String>,
    val respostaCerta: String
)
