package com.example.tentativa.ecras

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tentativa.R

@Composable
fun QuizEndScreen(playerScore: Int, onBackToMenu: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.fundopng), // Replace with your image resource ID
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Fim do quiz", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            InfoText("Você chegou ao fim do quiz, acertou $playerScore perguntas de 10")
            InfoText("Pode consultar a sua pontuação e a dos outros jogadores na categoria pontuação dos jogadores.")
            Button(
                onClick = onBackToMenu,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(50.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF757575).copy(alpha = 0.5f))
            ) {
                Text("Voltar ao menu inicial", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
fun InfoText(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.8f)
            .background(Color(0xFF757575).copy(alpha = 0.255f), RoundedCornerShape(12.dp)) // Alterado de 0.5 para 0.625
            .padding(16.dp)
    ) {
        Text(text, fontSize = 18.sp, color = Color.Black)
    }
}