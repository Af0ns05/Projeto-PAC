package com.example.tentativa.ecras

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.tentativa.viewmodel.MainViewModel

@Composable
fun MainScreen(viewModel: MainViewModel, onExit: () -> Unit) {
    var currentScreen by remember { mutableStateOf("MainMenu") }
    var selectedTheme by remember { mutableStateOf("") }
    var playerName by remember { mutableStateOf("") }
    var playerScore by remember { mutableStateOf(0) }

    when (currentScreen) {
        "MainMenu" -> MainMenu(
            onStartQuiz = { currentScreen = "QuizMenu" },
            onHowToPlay = { currentScreen = "HowToPlay" },
            onViewScores = { currentScreen = "Scores" },
            onSuggestQuestion = { currentScreen = "SuggestQuestion" },
            onExit = onExit
        )
        "QuizMenu" -> QuizMenu(
            onBack = { currentScreen = "MainMenu" },
            onSelectTheme = { theme ->
                selectedTheme = theme
                currentScreen = "EnterName"
            }
        )
        "HowToPlay" -> HowToPlayMenu(onBack = { currentScreen = "MainMenu" })
        "Scores" -> ScoresMenu(
            viewModel = viewModel,
            onBack = { currentScreen = "MainMenu" }
        )
        "EnterName" -> EnterNameScreen(
            selectedTheme = selectedTheme,
            onBack = { currentScreen = "QuizMenu" },
            onProceed = { name ->
                playerName = name
                currentScreen = "Quiz"
            }
        )
        "Quiz" -> QuizScreen(
            viewModel = viewModel,
            selectedTheme = selectedTheme,
            playerName = playerName,
            onBack = { currentScreen = "MainMenu" },
            onFinish = { score ->
                playerScore = score
                currentScreen = "QuizEnd"
            }
        )
        "QuizEnd" -> QuizEndScreen(
            playerScore = playerScore,
            onBackToMenu = { currentScreen = "MainMenu" }
        )
        "SuggestQuestion" -> SuggestQuestionScreen(
            viewModel = viewModel,
            onBack = { currentScreen = "MainMenu" },
            onBackToMenu = { currentScreen = "MainMenu" }
        )
    }
}
