package com.example.tentativa.ecras

import com.example.tentativa.PlayerScoreEntity
import com.example.tentativa.QuestionEntity
import androidx.room.*

@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions WHERE theme = :theme")
    fun getQuestionsByTheme(theme: String): List<QuestionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: QuestionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestions(questions: List<QuestionEntity>)
}

@Dao
interface PlayerScoreDao {
    @Query("SELECT * FROM player_scores ORDER BY score DESC")
    fun getAllScores(): List<PlayerScoreEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayerScore(score: PlayerScoreEntity)
}
